class Pathutils:
    def clean_path(self, path):
        return path.replace("\n", "")
